/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author alexg
 */
public class Procesar extends HttpServlet {
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,IOException{
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String edad = request.getParameter("edad");
        
        if (nombre.equals("")||apellido.equals("")|| edad.equals("")){
            request.getRequestDispatcher("errorcampos.jsp").forward(request, response);
        }else{
            int ed =0;
            try{
                ed = Integer.parseInt(edad);
            }catch(NumberFormatException ex){
                request.getRequestDispatcher("errornum.jsp").forward(request, response);
            }
        Usuario ul = new Usuario(nombre, apellido, ed);
        request.getSession().setAttribute("Usuario1", ul);
        
        request.getRequestDispatcher("aceptable.jsp").forward(request, response);
        }
    }
}